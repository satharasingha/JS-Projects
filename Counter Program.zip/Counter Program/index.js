 let count = 0;

  const updateLabel = () => {
    document.getElementById("label1").textContent = count;
  };

  const increment = () => {
    count++;
    updateLabel();
  };

  const decrement = () => {
    count--;
    updateLabel();
  };

  document.getElementById("btn1").onclick = increment;
  document.getElementById("btn2").onclick = decrement;